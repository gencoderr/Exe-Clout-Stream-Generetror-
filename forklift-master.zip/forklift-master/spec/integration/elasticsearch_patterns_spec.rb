require 'spec_helper'

describe 'elasticsearch patterns' do  

end