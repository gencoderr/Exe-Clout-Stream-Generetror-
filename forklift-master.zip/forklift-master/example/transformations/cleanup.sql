ALTER TABLE `users` DROP `combined_name`;
