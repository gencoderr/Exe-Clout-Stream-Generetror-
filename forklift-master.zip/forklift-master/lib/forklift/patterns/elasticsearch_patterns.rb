module Forklift
  module Patterns
    class Elasticsearch

    end
  end
end
