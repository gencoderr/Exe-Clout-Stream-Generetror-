const kTestAssetsDir = './test/assets';
