const kVendorName = 'Fontify';
const kVendorUrl = 'https://github.com/westracer/fontify';
