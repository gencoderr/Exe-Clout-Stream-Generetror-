import 'package:xml/xml.dart';

import 'element.dart';

class UnknownElement extends SvgElement {
  UnknownElement(SvgElement? parent, XmlElement? element)
      : super(parent, element);
}
