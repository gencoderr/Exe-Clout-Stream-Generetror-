import 'otf.dart';

/// Reads OpenType font from a file.
OpenTypeFont readFromFile(String path) =>
    throw UnsupportedError('Supported only with dart:io');

/// Writes OpenType font to a file.
void writeToFile(String path, OpenTypeFont font) =>
    throw UnsupportedError('Supported only with dart:io');
