library fontify.utils;

export 'utils/exception.dart';
export 'utils/flutter_class_gen.dart';
