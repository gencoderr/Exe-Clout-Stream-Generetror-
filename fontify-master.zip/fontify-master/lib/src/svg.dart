library fontify.svg;

export 'svg/svg.dart';
