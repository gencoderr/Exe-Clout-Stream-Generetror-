---
name: "\U0001F41B Bug report"
about: See CONTRIBUTING.md for more information
title: ''
labels: bug, help wanted
assignees: ''

---

## Describe the bug

A clear and concise description of what the bug is.

## To Reproduce

Provide detailed steps to reproduce, **an executable script would be best**.

## Expected behavior

A clear and concise description of what you expected to happen.

## My environment

- Affects my production application: **YES/NO**
- Ruby version: ...
- OS: ...
