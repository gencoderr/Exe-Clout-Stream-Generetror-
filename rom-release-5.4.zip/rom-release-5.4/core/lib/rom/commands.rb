# frozen_string_literal: true

require 'rom/commands/create'
require 'rom/commands/update'
require 'rom/commands/delete'
