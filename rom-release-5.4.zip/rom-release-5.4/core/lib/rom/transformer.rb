# frozen_string_literal: true

require 'transproc/transformer'

require 'rom/processor/transproc'

module ROM
  # Transformer is a data mapper which uses Transproc's transformer DSL to define
  # transformations.
  #
  # @api public
  class Transformer < Transproc::Transformer[::ROM::Processor::Transproc::Functions]
    extend ::Dry::Core::ClassAttributes

    # @!method self.register_as
    #  Get or set registration name
    #
    #  @overload register_as
    #    Return the registration name
    #    @return [Symbol]
    #
    #  @overload register_as(name)
    #    Configure registration name
    #
    #    @example
    #      class MyMapper < ROM::Transformer
    #        relation :users
    #        register_as :my_mapper
    #      end
    #
    #    @param name [Symbol] The registration name
    defines :register_as

    # Configure relation for the transformer
    #
    # @example with a custom name
    #   class UsersMapper < ROM::Transformer
    #     relation :users, as: :json_serializer
    #
    #     map do
    #       rename_keys user_id: :id
    #       deep_stringify_keys
    #     end
    #   end
    #
    #   users.map_with(:json_serializer)
    #
    # @param name [Symbol]
    # @param options [Hash]
    # @option options :as [Symbol] Mapper identifier
    #
    # @api public
    def self.relation(name = Undefined, options = EMPTY_HASH)
      return @relation if name.equal?(Undefined) && defined?(@relation)

      register_as(options.fetch(:as, name))
      @relation = name
    end

    # Define transformation pipeline
    #
    # @example
    #   class UsersMapper < ROM::Transformer
    #     map do
    #       rename_keys user_id: :id
    #       deep_stringify_keys
    #     end
    #   end
    #
    # @return [self]
    #
    # @api public
    def self.map(&)
      define! do
        map_array(&)
      end
    end

    # This is needed to make transformers compatible with rom setup
    #
    # @api private
    def self.base_relation = relation

    # Build a mapper instance
    #
    # @return [Transformer]
    #
    # @api public
    def self.build = new
  end
end
