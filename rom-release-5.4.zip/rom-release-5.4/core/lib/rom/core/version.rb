# frozen_string_literal: true

module ROM
  module Core
    VERSION = '5.4.2'
  end
end
