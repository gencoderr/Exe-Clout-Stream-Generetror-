# frozen_string_literal: true

require 'rom/associations/definitions/many_to_many'
require 'rom/associations/definitions/many_to_one'
require 'rom/associations/definitions/one_to_many'
require 'rom/associations/definitions/one_to_one'
require 'rom/associations/definitions/one_to_one_through'
