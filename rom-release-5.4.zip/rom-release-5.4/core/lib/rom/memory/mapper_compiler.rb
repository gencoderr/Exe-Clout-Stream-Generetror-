# frozen_string_literal: true

require 'rom/mapper_compiler'

module ROM
  module Memory
    class MapperCompiler < ROM::MapperCompiler
    end
  end
end
