# frozen_string_literal: true

require 'rom/types'

module ROM
  module Memory
    module Types
      include ROM::Types
    end
  end
end
