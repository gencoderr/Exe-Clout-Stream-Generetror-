# frozen_string_literal: true

require 'rom/memory/associations/many_to_many'
require 'rom/memory/associations/many_to_one'
require 'rom/memory/associations/one_to_many'
require 'rom/memory/associations/one_to_one'
