# frozen_string_literal: true

class CreateUser
end
