# frozen_string_literal: true

class Users
end
