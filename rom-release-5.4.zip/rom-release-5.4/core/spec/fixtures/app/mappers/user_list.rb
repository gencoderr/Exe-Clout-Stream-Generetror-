# frozen_string_literal: true

class UserList
end
