# frozen_string_literal: true

module My
  module Namespace
    module Mappers
      class CustomerList
      end
    end
  end
end
