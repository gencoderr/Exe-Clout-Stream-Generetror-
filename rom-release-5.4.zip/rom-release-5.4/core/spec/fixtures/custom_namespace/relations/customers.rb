# frozen_string_literal: true

module My
  module Namespace
    module Relations
      class Customers
      end
    end
  end
end
