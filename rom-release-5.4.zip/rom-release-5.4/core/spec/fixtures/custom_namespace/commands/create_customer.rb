# frozen_string_literal: true

module My
  module Namespace
    module Commands
      class CreateCustomer
      end
    end
  end
end
