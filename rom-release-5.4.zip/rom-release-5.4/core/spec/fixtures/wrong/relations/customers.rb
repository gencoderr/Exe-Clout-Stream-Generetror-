# frozen_string_literal: true

module My
  module NewNamespace
    module Foo
      class Customers
      end
    end
  end
end
