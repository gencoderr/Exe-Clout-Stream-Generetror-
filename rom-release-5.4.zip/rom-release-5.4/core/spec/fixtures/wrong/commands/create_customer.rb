# frozen_string_literal: true

module My
  module NewNamespace
    module Foo
      class CreateCustomer
      end
    end
  end
end
