# frozen_string_literal: true

module My
  module NewNamespace
    module Foo
      class CustomerList
      end
    end
  end
end
