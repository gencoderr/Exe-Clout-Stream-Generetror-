# frozen_string_literal: true

module Persistence
  module MyRelations
    class Users
    end
  end
end
