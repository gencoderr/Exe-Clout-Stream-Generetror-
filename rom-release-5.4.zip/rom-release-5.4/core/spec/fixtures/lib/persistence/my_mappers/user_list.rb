# frozen_string_literal: true

module Persistence
  module MyMappers
    class UserList
    end
  end
end
