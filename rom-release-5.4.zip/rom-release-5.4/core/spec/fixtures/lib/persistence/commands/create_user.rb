# frozen_string_literal: true

module Persistence
  module Commands
    class CreateUser
    end
  end
end
