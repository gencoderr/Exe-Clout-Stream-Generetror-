# frozen_string_literal: true

module Persistence
  module Mappers
    class UserList
    end
  end
end
