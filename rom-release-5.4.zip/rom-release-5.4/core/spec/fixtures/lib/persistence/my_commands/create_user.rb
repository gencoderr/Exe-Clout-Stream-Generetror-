# frozen_string_literal: true

module Persistence
  module MyCommands
    class CreateUser
    end
  end
end
