# frozen_string_literal: true

module Persistence
  module Relations
    class Users
    end
  end
end
