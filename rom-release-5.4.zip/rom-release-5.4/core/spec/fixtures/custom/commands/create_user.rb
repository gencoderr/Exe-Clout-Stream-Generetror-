# frozen_string_literal: true

module My
  module Namespace
    class CreateUser
    end
  end
end
