# frozen_string_literal: true

module My
  module Namespace
    class Users
    end
  end
end
