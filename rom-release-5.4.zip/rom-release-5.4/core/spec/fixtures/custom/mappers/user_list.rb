# frozen_string_literal: true

module My
  module Namespace
    class UserList
    end
  end
end
