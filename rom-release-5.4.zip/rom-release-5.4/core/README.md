[gem]: https://rubygems.org/gems/rom-core

# rom-core [![Gitter chat](https://badges.gitter.im/rom-rb/chat.svg)](https://gitter.im/rom-rb/chat)

[![Gem Version](https://badge.fury.io/rb/rom-core.svg)][gem]

Core API for rom-rb and its adapters and extensions.

Resources:

* [User documentation](http://rom-rb.org/learn/core)
* [API documentation](http://api.rom-rb.org/rom/)

## License

See `LICENSE` file.
