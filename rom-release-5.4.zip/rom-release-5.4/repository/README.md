[gem]: https://rubygems.org/gems/rom-repository

# rom-repository

[![Gem Version](https://badge.fury.io/rb/rom-repository.svg)][gem]

Repositories for [rom-rb](https://github.com/rom-rb/rom) with auto-mapping, changesets and commands.

Resources:

* [User documentation](http://rom-rb.org/learn/repositories)
* [API documentation](http://api.rom-rb.org/rom/)

## License

See `LICENSE` file.
