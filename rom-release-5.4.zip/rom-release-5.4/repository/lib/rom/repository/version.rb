# frozen_string_literal: true

module ROM
  class Repository
    VERSION = '5.4.2'
  end
end
