# frozen_string_literal: true

require 'rom/core'
require 'rom/repository'
