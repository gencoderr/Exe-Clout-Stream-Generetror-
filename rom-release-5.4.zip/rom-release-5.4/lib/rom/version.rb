# frozen_string_literal: true

module ROM
  VERSION = '5.4.2'
end
