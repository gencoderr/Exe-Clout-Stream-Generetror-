[gem]: https://rubygems.org/gems/rom-changeset

# rom-changeset

[![Gem Version](https://badge.fury.io/rb/rom-changeset.svg)][gem]

Changesets for [rom-rb](https://github.com/rom-rb/rom) integrated with relations.

Resources:

* [User documentation](http://rom-rb.org/4.0/learn/core/changesets/)
* [API documentation](http://api.rom-rb.org/rom/)

## License

See `LICENSE` file.
