# frozen_string_literal: true

require 'rom/changeset'
require 'rom/plugins/relation/changeset'
