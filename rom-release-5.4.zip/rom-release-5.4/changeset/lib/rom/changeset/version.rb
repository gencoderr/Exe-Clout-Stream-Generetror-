# frozen_string_literal: true

module ROM
  class Changeset
    VERSION = '5.4.2'
  end
end
