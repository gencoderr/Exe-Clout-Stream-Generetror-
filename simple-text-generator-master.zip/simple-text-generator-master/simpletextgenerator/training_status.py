class TrainingStatus:
    NEW = "NEW"
    NEW_LOAD_MODEL = "NEW_LOAD_MODEL"
    STARTED = "STARTED"
    FINISHED = "FINISHED"
