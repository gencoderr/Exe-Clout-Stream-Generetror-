# How to contribute

The Chrome Root Program Policy is maintained by members of the Chrome Security team. 

We accept feedback in lieu of GitHub issues at chrome-root-program [at] google [dot] com.
