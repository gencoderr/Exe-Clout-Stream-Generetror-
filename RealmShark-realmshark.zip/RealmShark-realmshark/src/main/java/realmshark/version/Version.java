package realmshark.version;
/**
 * Don't edit this class. It's a gradle class to grab version from the build.gradle
 */
public class Version {
    public static final String VERSION = "v1.1";
}

