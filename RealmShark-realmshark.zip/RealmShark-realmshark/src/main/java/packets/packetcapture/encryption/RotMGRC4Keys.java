package packets.packetcapture.encryption;

public class RotMGRC4Keys {
    // Incoming packet key from the rotmg servers to the client.
    public static String INCOMING_STRING = "c91d9eec420160730d825604e0";
    // Outgoing packet key from the client to the rotmg servers.
    public static String OUTGOING_STRING = "5a4d2016bc16dc64883194ffd9";
}
