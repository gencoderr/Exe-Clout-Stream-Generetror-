
import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { Header } from './components/Header';
import { FileUpload } from './components/FileUpload';
import { FileList } from './components/FileList';
import { FileDetails } from './components/FileDetails';
import { AnalyticsChart } from './components/AnalyticsChart';
import { generateFileAnalysis } from './services/geminiService';
import { ExeFile, User } from './types';
import { GOOGLE_CLIENT_ID } from './config';
import { ICONS } from './constants';

// This tells TypeScript that the 'google' object will be available globally from the script tag.
declare const google: any;

// Simple JWT decoder
const decodeJwtResponse = (token: string) => {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    return JSON.parse(jsonPayload);
  } catch(e) {
    console.error("Error decoding JWT", e);
    return null;
  }
}

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [files, setFiles] = useState<ExeFile[]>([]);
  const [selectedFileId, setSelectedFileId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isGsiInitialized, setIsGsiInitialized] = useState(false);
  const [originUrl, setOriginUrl] = useState<string>('');

  useEffect(() => {
    if (typeof window !== 'undefined') {
        setOriginUrl(window.location.origin);
    }
  }, []);

  const handleCredentialResponse = useCallback((response: any) => {
    const userObject = decodeJwtResponse(response.credential);
    if (userObject) {
      setUser({
        name: userObject.name,
        email: userObject.email,
        picture: userObject.picture,
      });
    } else {
      setError("Failed to process Google Sign-In. Please try again.");
    }
  }, []);

  const handleSignOut = useCallback(() => {
    google.accounts.id.disableAutoSelect();
    setUser(null);
    setFiles([]);
    setSelectedFileId(null);
    setError(null);
  }, []);

  useEffect(() => {
    if (google) {
      google.accounts.id.initialize({
        client_id: GOOGLE_CLIENT_ID,
        callback: handleCredentialResponse
      });
      setIsGsiInitialized(true);
    }
  }, [handleCredentialResponse]);


  const handleFileUpload = useCallback(async (uploadedFiles: File[]) => {
    setIsLoading(true);
    setError(null);
    try {
      const newExeFiles: ExeFile[] = [];
      for (const file of uploadedFiles) {
        // Basic validation for .exe files
        if (!file.name.toLowerCase().endsWith('.exe')) {
            console.warn(`Skipping non-exe file: ${file.name}`);
            continue;
        }

        const analysis = await generateFileAnalysis(file.name);
        const newFile: ExeFile = {
          id: `${file.name}-${new Date().getTime()}`,
          name: file.name,
          size: file.size,
          uploadDate: new Date(),
          description: analysis.description,
          tags: analysis.tags,
          warning: analysis.warning,
          groundingChunks: analysis.groundingChunks,
          rawFile: file,
          isCloudReady: false,
          cloudDescription: '',
        };
        newExeFiles.push(newFile);
      }
      
      if (newExeFiles.length > 0) {
        setFiles(prevFiles => [...newExeFiles, ...prevFiles]);
        setSelectedFileId(newExeFiles[0].id);
      } else {
        setError("No valid .exe files were selected for upload.");
      }

    } catch (err) {
      console.error("Error processing files:", err);
      setError("Failed to analyze files. Please check your API key and try again.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleUpdateFile = useCallback((fileId: string, updatedFile: Partial<ExeFile>) => {
    setFiles(prevFiles =>
      prevFiles.map(f => (f.id === fileId ? { ...f, ...updatedFile } : f))
    );
  }, []);

  const selectedFile = useMemo(() => {
    return files.find(f => f.id === selectedFileId) || null;
  }, [files, selectedFileId]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 font-sans flex flex-col">
      <Header user={user} onSignOut={handleSignOut} isGsiReady={isGsiInitialized} />
      <main className="flex-grow flex flex-col p-4 gap-4 overflow-hidden">
        {user ? (
          <div className="flex flex-col md:flex-row h-full gap-4 flex-grow">
            <div className="md:w-1/3 lg:w-1/4 flex flex-col gap-4 h-full">
              <FileUpload onFileUpload={handleFileUpload} isLoading={isLoading} />
              <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-4 flex-grow overflow-y-auto border border-gray-700">
                <h2 className="text-lg font-semibold mb-3 text-cyan-400">Uploaded Files</h2>
                <FileList
                  files={files}
                  selectedFileId={selectedFileId}
                  onSelectFile={setSelectedFileId}
                />
              </div>
            </div>
            <div className="md:w-2/3 lg:w-3/4 flex flex-col gap-4 h-full">
              <FileDetails file={selectedFile} error={error} onUpdateFile={handleUpdateFile} />
              <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-4 flex-grow border border-gray-700 min-h-[300px]">
                <h2 className="text-lg font-semibold mb-3 text-cyan-400">File Category Analytics</h2>
                <AnalyticsChart files={files} />
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-grow flex items-center justify-center">
              <div className="text-center p-4">
                  <h2 className="text-3xl font-bold text-white mb-2">Welcome to your EXE Portal</h2>
                  <p className="text-gray-400">Please sign in with Google to manage your files.</p>
                  
                  {originUrl && (
                        <div className="mt-8 bg-gray-800 border border-amber-500/50 rounded-lg p-6 max-w-2xl mx-auto text-left">
                            <div className="flex items-start gap-3">
                                <div className="text-amber-400 pt-1">{ICONS.WARNING}</div>
                                <div>
                                    <h3 className="font-bold text-amber-300">Getting a Sign-In Error (401: invalid_client)?</h3>
                                    <p className="text-sm text-gray-300 mt-2">
                                        This is a common configuration issue. To fix it, you must add your application's URL to the list of authorized domains in your Google Cloud project.
                                    </p>
                                    <p className="text-sm text-gray-300 mt-3">
                                        <strong>1. Copy this exact URL:</strong>
                                    </p>
                                    <pre className="bg-gray-900 text-cyan-300 p-2 rounded-md mt-1 text-sm overflow-x-auto"><code>{originUrl}</code></pre>
                                    <p className="text-sm text-gray-300 mt-3">
                                        <strong>2. Add it to your "Authorized JavaScript origins"</strong> in the Google Cloud Console.
                                    </p>
                                    <a 
                                        href="https://console.cloud.google.com/apis/credentials" 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        className="mt-3 inline-block text-cyan-400 hover:text-cyan-300 hover:underline text-sm"
                                    >
                                        Open Google Cloud Credentials &rarr;
                                    </a>
                                    <p className="text-xs text-gray-500 mt-2">
                                        Find your OAuth 2.0 Client ID in the list, click to edit it, and paste the URL. It may take a few minutes for the change to take effect.
                                    </p>
                                </div>
                            </div>
                        </div>
                    )}
              </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
