// config.ts

/**
 * ===================================================================
 * A P P L I C A T I O N   C O N F I G U R A T I O N
 * ===================================================================
 * 
 * This file contains the configuration keys for external services.
 */

/**
 * GOOGLE OAUTH 2.0 CLIENT ID
 * 
 * This is the public Client ID for the Google Sign-In functionality.
 * You can obtain this from the Google Cloud Console for your project.
 * It should end with ".apps.googleusercontent.com".
 * 
 * !!! IMPORTANT !!!
 * This is your public Client ID, NOT your Client Secret or an API Key.
 * - Client Secrets (which often start with "GOCSPX-") should NEVER be placed in frontend code.
 * - API Keys (which often start with "AIza") are for other Google services and will not work for Sign-In.
 */
export const GOOGLE_CLIENT_ID = "189631228671-krfkjg983bep49b8pvsmg5omeg9jjjpj.apps.googleusercontent.com";
