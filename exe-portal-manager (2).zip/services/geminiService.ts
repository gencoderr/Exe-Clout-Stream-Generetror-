import { GoogleGenAI, Type } from "@google/genai";
import { FileAnalysis, GroundingChunk } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const DESCRIPTION_PROMPT = (filename: string) => `
Based on the filename "${filename}" and information from a web search, provide a plausible, one-paragraph description of what this software might do. 
Be creative but professional. Imagine you are writing a summary for a software catalog.
`;

const WARNING_PROMPT = `
Generate a concise, one-sentence security warning about the risks of running an unknown executable file from the internet.
`;

const CLOUD_DESCRIPTION_PROMPT = (filename: string, originalDescription: string) => `
The following is a description of a desktop application called "${filename}":
"${originalDescription}"

Now, imagine this application has been completely re-engineered as a cloud-native, browser-based service.
Write a new, exciting, one-paragraph description for this cloud version.
Focus on the benefits like universal accessibility from any device, real-time collaboration, automatic updates, and powerful scalability.
Do not mention the old version or that this is a hypothetical upgrade. Present it as a real, cutting-edge cloud application.
`;

const SIMULATE_LAUNCH_PROMPT = (filename: string, cloudDescription: string) => `
You are a cloud-based application named "${filename}".
Your function is described as: "${cloudDescription}".
A user has just launched you.
Generate a plausible, text-based output that would appear in a terminal or log window upon a successful launch.
The output should be formatted like a log, with status indicators (e.g., [INFO], [SUCCESS], [INIT]).
Be creative. For example, if you are a game, mention connecting to servers. If you are a design tool, mention loading a project.
Keep the output concise, around 4-6 lines. Do not use markdown.
`;

const TAGS_SCHEMA = {
    type: Type.OBJECT,
    properties: {
        tags: {
            type: Type.ARRAY,
            description: "An array of up to 5 relevant tags (as lowercase strings) that categorize this software. Example tags: 'gaming', 'utility', 'productivity', 'security', 'development'.",
            items: { type: Type.STRING }
        }
    },
    required: ["tags"],
};

export const generateFileAnalysis = async (filename: string): Promise<FileAnalysis> => {
    try {
        // Run all requests in parallel for efficiency
        const [descriptionResponse, tagsResponse, warningResponse] = await Promise.all([
            // Description Generation with Google Search Grounding
            ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: DESCRIPTION_PROMPT(filename),
                config: {
                    temperature: 0.5,
                    tools: [{googleSearch: {}}],
                }
            }),
            // Tags Generation
            ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: `Analyze the filename "${filename}" and generate tags.`,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: TAGS_SCHEMA,
                }
            }),
            // Warning Generation
            ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: WARNING_PROMPT,
            })
        ]);
        
        const description = descriptionResponse.text.trim();
        const warning = warningResponse.text.trim();
        const groundingChunks = descriptionResponse.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[] | undefined;

        let tags: string[] = [];
        try {
            const tagsJson = JSON.parse(tagsResponse.text);
            if (tagsJson && Array.isArray(tagsJson.tags)) {
                tags = tagsJson.tags;
            }
        } catch (e) {
            console.error("Failed to parse tags JSON:", e);
            // Fallback tags based on filename
            tags = ['utility', 'software'];
        }

        return { description, tags, warning, groundingChunks };
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to get file analysis from Gemini API.");
    }
};

export const generateCloudAnalysis = async (filename: string, originalDescription: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: CLOUD_DESCRIPTION_PROMPT(filename, originalDescription),
            config: {
                temperature: 0.7,
            }
        });
        return response.text.trim();
    } catch (error) {
        console.error("Error calling Gemini API for cloud analysis:", error);
        throw new Error("Failed to get cloud analysis from Gemini API.");
    }
};

export const simulateCloudLaunch = async (filename: string, cloudDescription: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: SIMULATE_LAUNCH_PROMPT(filename, cloudDescription),
            config: {
                temperature: 0.6,
            }
        });
        return response.text.trim();
    } catch (error) {
        console.error("Error calling Gemini API for cloud launch simulation:", error);
        throw new Error("Failed to simulate cloud launch from Gemini API.");
    }
};