
import React, { useMemo } from 'react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { ExeFile } from '../types';

interface AnalyticsChartProps {
  files: ExeFile[];
}

const COLORS = ['#06b6d4', '#8b5cf6', '#ec4899', '#f97316', '#10b981', '#f59e0b', '#6366f1', '#d946ef'];

export const AnalyticsChart: React.FC<AnalyticsChartProps> = ({ files }) => {
  const data = useMemo(() => {
    const tagCount: { [key: string]: number } = {};
    files.forEach(file => {
      file.tags.forEach(tag => {
        tagCount[tag] = (tagCount[tag] || 0) + 1;
      });
    });

    return Object.entries(tagCount).map(([name, value]) => ({ name, value }));
  }, [files]);

  if (files.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-gray-500">
        <p>Upload files to see analytics data.</p>
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height="100%">
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="50%"
          labelLine={false}
          outerRadius="80%"
          fill="#8884d8"
          dataKey="value"
          nameKey="name"
          stroke="#1f2937"
        >
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip
          contentStyle={{
            background: 'rgba(31, 41, 55, 0.8)', // bg-gray-800 with opacity
            borderColor: '#4b5563', // border-gray-600
            borderRadius: '0.5rem',
            color: '#d1d5db', // text-gray-300
          }}
          itemStyle={{ color: '#d1d5db' }}
        />
        <Legend
           wrapperStyle={{ color: '#d1d5db' }}
        />
      </PieChart>
    </ResponsiveContainer>
  );
};
