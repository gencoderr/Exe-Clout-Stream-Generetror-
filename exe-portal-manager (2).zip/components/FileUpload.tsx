
import React, { useState, useCallback } from 'react';
import { ICONS } from '../constants';
import { Spinner } from './Spinner';

interface FileUploadProps {
  onFileUpload: (files: File[]) => void;
  isLoading: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileUpload, isLoading }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragEnter = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onFileUpload(Array.from(e.dataTransfer.files));
      e.dataTransfer.clearData();
    }
  }, [onFileUpload]);
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileUpload(Array.from(e.target.files));
      e.target.value = ''; // Reset input to allow re-uploading the same file
    }
  };

  return (
    <div
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
      className={`relative bg-gray-800/50 border-2 ${isDragging ? 'border-cyan-400' : 'border-dashed border-gray-600'} rounded-lg p-6 text-center transition-colors duration-200 cursor-pointer`}
    >
      <input
        type="file"
        multiple
        accept=".exe"
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
        onChange={handleFileChange}
        disabled={isLoading}
      />
      {isLoading ? (
        <div className="flex flex-col items-center justify-center gap-2">
            <Spinner/>
            <p className="text-sm text-gray-400">Analyzing files...</p>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center gap-2">
          {ICONS.UPLOAD}
          <p className="text-sm text-gray-400">
            <span className="font-semibold text-cyan-400">Click to upload</span> or drag and drop
          </p>
          <p className="text-xs text-gray-500">.EXE files only</p>
        </div>
      )}
    </div>
  );
};
