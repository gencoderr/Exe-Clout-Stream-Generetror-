
import React from 'react';

interface ErrorMessageProps {
    message: string;
}

export const ErrorMessage: React.FC<ErrorMessageProps> = ({ message }) => {
    return (
        <div className="bg-red-900/30 border border-red-600/50 text-red-300 p-4 rounded-lg text-center">
            <h3 className="font-bold text-lg mb-1">An Error Occurred</h3>
            <p className="text-sm">{message}</p>
        </div>
    );
};
