import React, { useEffect, useRef } from 'react';
import { ICONS } from '../constants';
import { User } from '../types';

// This tells TypeScript that the 'google' object will be available globally from the script tag.
declare const google: any;

interface HeaderProps {
  user: User | null;
  onSignOut: () => void;
  isGsiReady: boolean;
}

export const Header: React.FC<HeaderProps> = ({ user, onSignOut, isGsiReady }) => {
  const signInButtonRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isGsiReady && !user && signInButtonRef.current) {
      // Clear the container to avoid rendering multiple buttons on re-renders.
      signInButtonRef.current.innerHTML = '';
      
      // Render the Google Sign-In button
      google.accounts.id.renderButton(
        signInButtonRef.current,
        { theme: "outline", size: "large" }  // Customize the button
      );
    }
  }, [user, isGsiReady]);


  return (
    <header className="bg-gray-800/30 backdrop-blur-md border-b border-gray-700 p-4 sticky top-0 z-10">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center gap-3">
            {ICONS.LOGO}
            <h1 className="text-2xl font-bold tracking-wider text-white">EXE Portal <span className="text-cyan-400">Manager</span></h1>
        </div>

        <div>
          {user ? (
            <div className="flex items-center gap-4">
                <div className="flex items-center gap-3">
                    {user.picture ? (
                      <img src={user.picture} alt={user.name} className="h-8 w-8 rounded-full" />
                    ) : (
                      ICONS.USER_AVATAR
                    )}
                    <span className="text-sm font-medium text-gray-200">Welcome, {user.name.split(' ')[0]}</span>
                </div>
                <button 
                    onClick={onSignOut}
                    className="bg-gray-700 hover:bg-gray-600 text-white text-sm font-bold py-2 px-3 rounded-md transition-colors duration-200"
                >
                    Sign Out
                </button>
            </div>
          ) : (
            <div ref={signInButtonRef} id="google-signin-button"></div>
          )}
        </div>
      </div>
    </header>
  );
};