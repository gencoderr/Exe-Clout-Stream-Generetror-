
import React from 'react';
import { ExeFile } from '../types';
import { ICONS } from '../constants';

interface FileListItemProps {
  file: ExeFile;
  isSelected: boolean;
  onSelect: () => void;
}

const formatBytes = (bytes: number, decimals = 2) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

export const FileListItem: React.FC<FileListItemProps> = ({ file, isSelected, onSelect }) => {
  return (
    <li
      onClick={onSelect}
      className={`flex items-center gap-3 p-3 rounded-md cursor-pointer transition-colors duration-200 ${
        isSelected ? 'bg-cyan-600/30' : 'hover:bg-gray-700/50'
      }`}
    >
      {ICONS.FILE_EXE}
      <div className="flex-grow overflow-hidden">
        <p className="text-sm font-medium text-gray-100 truncate">{file.name}</p>
        <p className="text-xs text-gray-400">{formatBytes(file.size)}</p>
      </div>
      {file.isCloudReady && (
        <div className="text-blue-400" title="Cloud Ready">
          {ICONS.CLOUD}
        </div>
       )}
    </li>
  );
};
