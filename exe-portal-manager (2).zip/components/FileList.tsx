
import React from 'react';
import { ExeFile } from '../types';
import { FileListItem } from './FileListItem';

interface FileListProps {
  files: ExeFile[];
  selectedFileId: string | null;
  onSelectFile: (id: string) => void;
}

export const FileList: React.FC<FileListProps> = ({ files, selectedFileId, onSelectFile }) => {
  if (files.length === 0) {
    return (
      <div className="text-center text-gray-500 mt-8">
        <p>No files uploaded yet.</p>
        <p className="text-sm">Use the panel above to add files.</p>
      </div>
    );
  }

  return (
    <ul className="space-y-2">
      {files.map(file => (
        <FileListItem
          key={file.id}
          file={file}
          isSelected={file.id === selectedFileId}
          onSelect={() => onSelectFile(file.id)}
        />
      ))}
    </ul>
  );
};
