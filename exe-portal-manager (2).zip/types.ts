export interface GroundingChunk {
  web: {
    uri: string;
    title: string;
  };
}

export interface User {
  name: string;
  email: string;
  picture?: string;
}

export interface ExeFile {
  id: string;
  name: string;
  size: number;
  uploadDate: Date;
  description: string;
  tags: string[];
  warning: string;
  rawFile: File;
  isCloudReady?: boolean;
  cloudDescription?: string;
  groundingChunks?: GroundingChunk[];
}

export interface FileAnalysis {
  description: string;
  tags: string[];
  warning: string;
  groundingChunks?: GroundingChunk[];
}