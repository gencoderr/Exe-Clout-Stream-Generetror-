# [Checkpoint Counter](https://openplanet.dev/plugin/checkpointcounter)

[![Version](https://img.shields.io/badge/dynamic/json?color=pink&label=Version&query=version&url=https%3A%2F%2Fopenplanet.dev%2Fapi%2Fplugin%2F79)](https://openplanet.dev/plugin/checkpointcounter)
[![Total Downloads](https://img.shields.io/badge/dynamic/json?color=green&label=Downloads&query=downloads&url=https%3A%2F%2Fopenplanet.dev%2Fapi%2Fplugin%2F79)](https://openplanet.dev/plugin/checkpointcounter)
![Tags 1](https://img.shields.io/badge/dynamic/json?color=blue&label=Game&query=tags%5B0%5D.name&url=https%3A%2F%2Fopenplanet.dev%2Fapi%2Fplugin%2F79)
![Tags 2](https://img.shields.io/badge/dynamic/json?color=blue&label=Game&query=tags%5B1%5D.name&url=https%3A%2F%2Fopenplanet.dev%2Fapi%2Fplugin%2F79)
![Tags 3](https://img.shields.io/badge/dynamic/json?color=blue&label=Game&query=tags%5B2%5D.name&url=https%3A%2F%2Fopenplanet.dev%2Fapi%2Fplugin%2F79)

An OpenPlanet plugin to show checkpoint counts in Trackmania games
