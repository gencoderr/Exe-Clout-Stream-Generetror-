Fix all black, isort, flake8 and mypy issues in the entire codebase
