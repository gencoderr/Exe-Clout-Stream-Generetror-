Follow RED-GREEN-REFACTOR cycle approch based on @~/.claude/CLAUDE.md:
1. Open todo.md and select the first unchecked items to work on.
2. Carefully plan each item, then share your plan
3. Create a new branch and implement your plan
4. Check off the items on todo.md
5. Commit your changes
