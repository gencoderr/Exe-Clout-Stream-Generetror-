# Load Xatu Data Context
READ the llms.txt file from https://raw.githubusercontent.com/ethpandaops/xatu-data/refs/heads/master/llms.txt via `curl`. Do nothing else and await further instructions.