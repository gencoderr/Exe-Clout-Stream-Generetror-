
export interface ExeFile {
  id: string;
  name: string;
  size: number;
  uploadDate: Date;
  description: string;
  tags: string[];
  warning: string;
  rawFile: File;
  isCloudReady?: boolean;
  cloudDescription?: string;
}

export interface FileAnalysis {
  description: string;
  tags: string[];
  warning: string;
}
