
import React, { useState, useCallback, useMemo } from 'react';
import { Header } from './components/Header';
import { FileUpload } from './components/FileUpload';
import { FileList } from './components/FileList';
import { FileDetails } from './components/FileDetails';
import { AnalyticsChart } from './components/AnalyticsChart';
import { generateFileAnalysis } from './services/geminiService';
import { ExeFile } from './types';

const App: React.FC = () => {
  const [files, setFiles] = useState<ExeFile[]>([]);
  const [selectedFileId, setSelectedFileId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = useCallback(async (uploadedFiles: File[]) => {
    setIsLoading(true);
    setError(null);
    try {
      const newExeFiles: ExeFile[] = [];
      for (const file of uploadedFiles) {
        // Basic validation for .exe files
        if (!file.name.toLowerCase().endsWith('.exe')) {
            console.warn(`Skipping non-exe file: ${file.name}`);
            continue;
        }

        const analysis = await generateFileAnalysis(file.name);
        const newFile: ExeFile = {
          id: `${file.name}-${new Date().getTime()}`,
          name: file.name,
          size: file.size,
          uploadDate: new Date(),
          description: analysis.description,
          tags: analysis.tags,
          warning: analysis.warning,
          rawFile: file,
          isCloudReady: false,
          cloudDescription: '',
        };
        newExeFiles.push(newFile);
      }
      
      if (newExeFiles.length > 0) {
        setFiles(prevFiles => [...newExeFiles, ...prevFiles]);
        setSelectedFileId(newExeFiles[0].id);
      } else {
        setError("No valid .exe files were selected for upload.");
      }

    } catch (err) {
      console.error("Error processing files:", err);
      setError("Failed to analyze files. Please check your API key and try again.");
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleUpdateFile = useCallback((fileId: string, updatedFile: Partial<ExeFile>) => {
    setFiles(prevFiles =>
      prevFiles.map(f => (f.id === fileId ? { ...f, ...updatedFile } : f))
    );
  }, []);

  const selectedFile = useMemo(() => {
    return files.find(f => f.id === selectedFileId) || null;
  }, [files, selectedFileId]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 font-sans flex flex-col">
      <Header />
      <main className="flex-grow flex flex-col md:flex-row p-4 gap-4 overflow-hidden">
        <div className="md:w-1/3 lg:w-1/4 flex flex-col gap-4 h-full">
          <FileUpload onFileUpload={handleFileUpload} isLoading={isLoading} />
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-4 flex-grow overflow-y-auto border border-gray-700">
            <h2 className="text-lg font-semibold mb-3 text-cyan-400">Uploaded Files</h2>
            <FileList
              files={files}
              selectedFileId={selectedFileId}
              onSelectFile={setSelectedFileId}
            />
          </div>
        </div>
        <div className="md:w-2/3 lg:w-3/4 flex flex-col gap-4 h-full">
          <FileDetails file={selectedFile} error={error} onUpdateFile={handleUpdateFile} />
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-4 flex-grow border border-gray-700 min-h-[300px]">
            <h2 className="text-lg font-semibold mb-3 text-cyan-400">File Category Analytics</h2>
            <AnalyticsChart files={files} />
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
