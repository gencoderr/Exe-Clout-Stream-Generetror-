import React, { useState } from 'react';
import { ExeFile } from '../types';
import { ICONS } from '../constants';
import { ErrorMessage } from './ErrorMessage';
import { Spinner } from './Spinner';
import { generateCloudAnalysis, simulateCloudLaunch } from '../services/geminiService';

interface FileDetailsProps {
  file: ExeFile | null;
  error: string | null;
  onUpdateFile: (id: string, updatedFile: Partial<ExeFile>) => void;
}

const formatBytes = (bytes: number, decimals = 2) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};

export const FileDetails: React.FC<FileDetailsProps> = ({ file, error, onUpdateFile }) => {
  const [isConverting, setIsConverting] = useState(false);
  const [conversionError, setConversionError] = useState<string | null>(null);
  
  const [isLaunching, setIsLaunching] = useState(false);
  const [launchOutput, setLaunchOutput] = useState<string | null>(null);
  const [launchError, setLaunchError] = useState<string | null>(null);


  if (error) {
      return (
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 flex-grow border border-gray-700 flex items-center justify-center">
            <ErrorMessage message={error} />
          </div>
      );
  }
  
  if (!file) {
    return (
      <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 flex-grow border border-gray-700 flex flex-col items-center justify-center text-center text-gray-500">
        <h3 className="text-xl font-semibold">Select a file</h3>
        <p>Choose a file from the list to see its details and AI-generated analysis.</p>
      </div>
    );
  }

  const handleDownload = () => {
    if (file.rawFile) {
        const url = URL.createObjectURL(file.rawFile);
        const a = document.createElement('a');
        a.href = url;
        a.download = file.name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
  };

  const handleConvertToCloud = async () => {
      if (!file) return;
      setIsConverting(true);
      setConversionError(null);
      try {
          const cloudDescription = await generateCloudAnalysis(file.name, file.description);
          onUpdateFile(file.id, {
              isCloudReady: true,
              cloudDescription: cloudDescription
          });
      } catch (err) {
          console.error("Cloud conversion failed:", err);
          setConversionError("Failed to generate cloud analysis. Please try again.");
      } finally {
          setIsConverting(false);
      }
  };

  const handleLaunchFromCloud = async () => {
    if (!file || !file.cloudDescription) return;
    setIsLaunching(true);
    setLaunchError(null);
    setLaunchOutput(null);
    try {
      const output = await simulateCloudLaunch(file.name, file.cloudDescription);
      setLaunchOutput(output);
    } catch (err) {
      console.error("Cloud launch failed:", err);
      setLaunchError("Failed to simulate cloud application launch. Please try again.");
    } finally {
      setIsLaunching(false);
    }
  };

  const closeLaunchModal = () => {
    setLaunchOutput(null);
    setLaunchError(null);
    setIsLaunching(false);
  }

  const handleCloudDownload = () => {
    if (!file || !file.cloudDescription || !launchOutput) return;

    const originalName = file.name.endsWith('.exe') ? file.name.slice(0, -4) : file.name;
    const newFileName = `${originalName}_cloud_version.txt`;

    const fileContent = `
--- Cloud Application Manifest ---
App Name: ${file.name}
Version: 1.0 (Cloud)
Download Date: ${new Date().toISOString()}

--- Cloud Description ---
${file.cloudDescription}

--- Last Launch Log ---
${launchOutput}
`;

    const blob = new Blob([fileContent.trim()], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = newFileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };


  return (
    <>
      <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 flex-grow border border-gray-700 flex flex-col gap-4 overflow-y-auto">
        <div className="flex justify-between items-start">
          <div>
              <h2 className="text-2xl font-bold text-cyan-400 break-all">{file.name}</h2>
              <div className="text-sm text-gray-400 mt-1 flex gap-4">
                  <span>Size: {formatBytes(file.size)}</span>
                  <span>Uploaded: {file.uploadDate.toLocaleDateString()}</span>
              </div>
          </div>
          {file.isCloudReady && (
              <div className="flex items-center gap-2 bg-blue-900/50 text-blue-300 text-sm font-semibold px-3 py-1 rounded-full border border-blue-700">
                  {ICONS.CLOUD}
                  <span>Cloud Ready</span>
              </div>
          )}
        </div>
        
        {file.isCloudReady && file.cloudDescription && (
          <div>
              <h3 className="text-lg font-semibold text-gray-200 mb-2">Cloud-Optimized Version</h3>
              <p className="text-gray-300 bg-gray-900/50 p-3 rounded-md border border-blue-800/50">{file.cloudDescription}</p>
          </div>
        )}

        <div>
          <h3 className="text-lg font-semibold text-gray-200 mb-2">{file.isCloudReady ? 'Original Description' : 'AI Generated Description'}</h3>
          <p className="text-gray-300 bg-gray-900/50 p-3 rounded-md">{file.description}</p>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-gray-200 mb-2">Suggested Tags</h3>
          <div className="flex flex-wrap gap-2">
              {file.tags.map(tag => (
                  <span key={tag} className="bg-gray-700 text-cyan-300 text-xs font-mono px-2 py-1 rounded">
                      {tag}
                  </span>
              ))}
          </div>
        </div>

        <div className="bg-amber-900/20 border border-amber-600/30 text-amber-300 p-3 rounded-md mt-2">
          <div className="flex items-start gap-3">
            {ICONS.WARNING}
            <div>
              <h4 className="font-semibold">Security Warning</h4>
              <p className="text-sm text-amber-200">{file.warning}</p>
            </div>
          </div>
        </div>
        
        {conversionError && <ErrorMessage message={conversionError} />}

        <div className="mt-auto flex flex-col md:flex-row gap-3 justify-end items-center pt-4">
          {!file.isCloudReady ? (
              <>
              <button 
                  onClick={handleConvertToCloud} 
                  disabled={isConverting}
                  className="w-full md:w-auto flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 px-4 rounded transition-colors duration-200 disabled:bg-indigo-800 disabled:cursor-not-allowed">
                  {isConverting ? <><Spinner className="h-5 w-5"/> Optimizing...</> : <>Make Cloud-Ready</>}
              </button>
              <button onClick={handleDownload} className="w-full md:w-auto bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2 px-4 rounded transition-colors duration-200">
                  Download File
              </button>
              </>
          ) : (
            <>
              <button onClick={handleDownload} className="w-full md:w-auto bg-gray-600 hover:bg-gray-500 text-white font-bold py-2 px-4 rounded transition-colors duration-200">
                  Download Original
              </button>
              <button 
                onClick={handleLaunchFromCloud}
                disabled={isLaunching}
                className="w-full md:w-auto flex items-center justify-center gap-2 bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded transition-colors duration-200 disabled:bg-green-800 disabled:cursor-not-allowed">
                  {isLaunching ? <><Spinner className="h-5 w-5" /> Launching...</> : <>Launch from Cloud</>}
              </button>
            </>
          )}
        </div>
      </div>
      
      {(isLaunching || launchOutput || launchError) && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={closeLaunchModal}>
          <div className="bg-gray-900 border border-gray-700 rounded-lg shadow-xl w-full max-w-2xl max-h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center p-4 border-b border-gray-700">
              <h3 className="text-lg font-semibold text-cyan-400">Cloud Application Stream: {file.name}</h3>
              <button onClick={closeLaunchModal} className="text-gray-400 hover:text-white transition-colors">&times;</button>
            </div>
            <div className="p-6 overflow-y-auto">
              {isLaunching && (
                 <div className="flex flex-col items-center justify-center gap-4 text-center">
                    <Spinner />
                    <p className="text-gray-300">Initializing cloud instance...</p>
                    <p className="text-sm text-gray-500">Please wait while we connect to the virtual environment.</p>
                 </div>
              )}
              {launchError && <ErrorMessage message={launchError} />}
              {launchOutput && (
                <div>
                  <h4 className="text-sm font-semibold text-gray-400 mb-2">TERMINAL OUTPUT:</h4>
                  <pre className="bg-black/50 p-4 rounded-md text-sm text-green-400 font-mono whitespace-pre-wrap overflow-x-auto">
                    <code>
                      {launchOutput}
                    </code>
                  </pre>
                </div>
              )}
            </div>
            <div className="p-4 border-t border-gray-700 flex justify-end gap-3">
                {launchOutput && (
                    <button onClick={handleCloudDownload} className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 px-4 rounded transition-colors duration-200">
                      Download Cloud Version
                    </button>
                )}
                <button onClick={closeLaunchModal} className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-2 px-4 rounded transition-colors duration-200">
                  Close Stream
                </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};