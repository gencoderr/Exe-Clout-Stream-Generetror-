
import React from 'react';
import { ICONS } from '../constants';

export const Header: React.FC = () => {
  return (
    <header className="bg-gray-800/30 backdrop-blur-md border-b border-gray-700 p-4 sticky top-0 z-10">
      <div className="container mx-auto flex items-center gap-3">
        {ICONS.LOGO}
        <h1 className="text-2xl font-bold tracking-wider text-white">EXE Portal <span className="text-cyan-400">Manager</span></h1>
      </div>
    </header>
  );
};
